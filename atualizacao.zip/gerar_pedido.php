<?php

ob_clean();
require('tfpdf/tfpdf.php');

$dados = json_decode($_POST['json'], true);
if (!$dados || !isset($dados['cliente']) || !isset($dados['itens'])) {
    http_response_code(400);
    echo "Dados inválidos.";
    exit;
}

$c = $dados['cliente'];
$itens = $dados['itens'];
$obs = $dados['observacoes'] ?? '';
$pagamento = $dados['condicoes'] ?? '';
$frete_tipo = $dados['frete'] ?? 'CIF';
$transportadora = $dados['transportadora'] ?? '';
$pedidoNum = $dados['numero'] ?? 'N/A';
$dataPedido = date('d/m/Y');

$pdf = new tFPDF();
$pdf->AddPage();
$pdf->AddFont('DejaVu', '', 'DejaVuSans.ttf', true);
$pdf->AddFont('DejaVu', 'B', 'DejaVuSans-Bold.ttf', true);

$pdf->SetFont('DejaVu', '', 10);

// Logo
$pdf->Image('logo.png', 10, 10, 40);

// Cabeçalho do pedido
$pdf->SetXY(150, 12);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(50, 6, "PEDIDO", 0, 2, 'C');

$pdf->SetFont('DejaVu', 'B', 14);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(50, 6, $pedidoNum, 0, 2, 'C');

$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('DejaVu', '', 9);
$pdf->Cell(50, 6, "Data da emissão", 0, 2, 'C');

$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(50, 6, $dataPedido, 0, 2, 'C');

$pdf->Ln(15);

// Dados do cliente
$pdf->SetDrawColor(0, 0, 0); // bordas pretas
$pdf->SetFillColor(255, 255, 255); // fundo branco (ou 220 para cinza claro)

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82); // texto azul nos dados

// Linha 1: NOME
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(25, 6, 'NOME:', 1, 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['nome'], 1, 1, 'L', true);

// Linha 2: ENDEREÇO, UF, CEP
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(25, 6, 'ENDEREÇO:', 1, 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(91, 6, $c['endereco'], 1, 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(6, 6, 'UF:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(40, 6, $c['uf'], 'TBR', 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(8, 6, 'CEP:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['cep'], 'TBR', 1, 'L', true);

// Linha 3: CIDADE, FONE, EMAIL
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(25, 6, 'CIDADE:', 1, 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(50, 6, $c['cidade'], 1, 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(15, 6, 'FONE:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(30, 6, $c['telefone'], 'TBR', 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(12, 6, 'EMAIL:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['email'], 'TBR', 1, 'L', true);

// Linha 4: CNPJ, INSC.EST., COMPRADOR
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(25, 6, 'CNPJ:', 1, 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(50, 6, $c['cnpj'], 1, 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(25, 6, 'INSC.EST.:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(50, 6, $c['inscEstadual'], 'TBR', 0, 'L', true);

$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(23, 6, 'COMPRADOR:', 'TBL', 0, 'L', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['comprador'], 'TBR', 1, 'L', true);


// Endereço de cobrança
// Linha 1
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(35, 6, 'END. DE COBRANÇA:', 'TBL', 0, 'L', true);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(50, 6, $c['endCobranca'] ?? '', 'TBR', 0, 'L', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(6, 6, 'UF:', 'TBL', 0, 'L', true);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(10, 6, $c['ufCobranca'] ?? '', 'TBR', 0, 'L', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(9, 6, 'CEP:', 'TBL', 0, 'L', true);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(25, 6, $c['cepCobranca'] ?? '', 'TBR', 0, 'L', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(15, 6, 'CIDADE:', 'TBL', 0, 'L', true);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['cidadeCobranca'] ?? '', 'TBR', 1, 'L', true);

// Linha 2
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(20, 6, 'CONTATO:', 'TBL', 0, 'L', true);
$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(0, 6, $c['contatoCobranca'] ?? '', 'TBR', 1, 'L', true);

// Linha divisória
$pdf->Ln(2);
$pdf->Cell(0, 0, '', 'T');
$pdf->Ln(4);


// Tabela de produtos
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetFillColor(220);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(20, 7, 'QUANT.', 1, 0, 'C', true);
$pdf->Cell(15, 7, 'UNID.', 1, 0, 'C', true);
$pdf->Cell(85, 7, 'DISCRIMINAÇÃO', 1, 0, 'C', true);
$pdf->Cell(35, 7, 'VALOR UNITARIO', 1, 0, 'C', true);
$pdf->Cell(35, 7, 'VALOR TOTAL', 1, 1, 'C', true);

$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(7, 64, 82);
$totalGeral = 0;
$maxLinhas = 15;
$linhasUsadas = 0;

foreach ($itens as $item) {
    $total = $item['preco'] * $item['qtd'];
    $totalGeral += $total;
    $pdf->Cell(20, 7, $item['qtd'], 1, 0, 'C');
    $pdf->Cell(15, 7, $item['unidade'] ?? 'Lt', 1, 0, 'C');
    $pdf->Cell(85, 7, $item['nome'], 1, 0, 'L');
    $pdf->Cell(35, 7, number_format($item['preco'], 2, ',', '.'), 1, 0, 'R');
    $pdf->Cell(35, 7, number_format($total, 2, ',', '.'), 1, 1, 'R');
    $linhasUsadas++;
}

// Linhas em branco
for ($i = $linhasUsadas; $i < $maxLinhas; $i++) {
    $pdf->Cell(20, 7, '', 1);
    $pdf->Cell(15, 7, '', 1);
    $pdf->Cell(85, 7, '', 1);
    $pdf->Cell(35, 7, '', 1);
    $pdf->Cell(35, 7, '', 1, 1);
}

// Total
$pdf->SetFont('DejaVu', 'B', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(155, 7, 'TOTAL', 1, 0, 'R');

$pdf->SetTextColor(7, 64, 82);
$pdf->Cell(35, 7, number_format($totalGeral, 2, ',', '.'), 1, 1, 'R');

$pdf->Ln(5);

// Observações
$pdf->SetFont('DejaVu', '', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(10, 6, 'OBS.:');
$pdf->SetTextColor(7, 64, 82);
$pdf->MultiCell(0, 6, $obs);
// Rodapé
$pdf->Cell(35, 6, 'TRANSPORTADORA:', 0, 0);
$pdf->Cell(80, 6, $transportadora, 0, 0);
$pdf->Cell(40, 6, 'FRETE:');
$pdf->Cell(10, 6, $frete_tipo == 'CIF' ? '(x)' : '( )');
$pdf->Cell(10, 6, 'CIF');
$pdf->Cell(10, 6, $frete_tipo == 'FOB' ? '(x)' : '( )');
$pdf->Cell(10, 6, 'FOB');

$pdf->Ln(7);
$pdf->Cell(50, 6, 'CONDICOES DE PAGAMENTO:', 0, 0);
$pdf->SetTextColor(255, 0, 0);
$pdf->Cell(50, 6, $pagamento);
$pdf->SetTextColor(0);

$pdf->Ln(15);

// Assinaturas
$pdf->Cell(95, 6, '_________________________________', 0, 0, 'C');
$pdf->Cell(95, 6, '_________________________________', 0, 1, 'C');
$pdf->Cell(95, 6, $c['vendedor'] ?? 'ASSINATURA DO VENDEDOR', 0, 0, 'C');
$pdf->Cell(95, 6, $c['comprador'] ?? 'ASSINATURA DO CLIENTE', 0, 1, 'C');

// Output
$pdf->Output('I', 'Pedido_' . preg_replace('/[^a-zA-Z0-9]/', '_', $c['nome']) . '.pdf');
